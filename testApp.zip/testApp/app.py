""" Flask app to run a server """
from flask import Flask, render_template, request, jsonify
import openai
#from openai import OpenAI
#client = OpenAI(
#    api_key="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"
#)

app = Flask(__name__)

# Set your OpenAI API key here
# openai.api_key = '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'

@app.route('/')
def home():
    """Render the home page"""
    return render_template('index.html')

@app.route('/generate_response', methods=['POST'])
def generate_response():
    """generate response from gpt-3.5-turbo"""
    user_input = request.form['user_input']

    # Call the OpenAI API to get a response
    response = openai.chat.completions.create(
    messages=[
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": user_input},
    ],
    model="gpt-3.5-turbo",
)
    ai_response = response.choices[0].message.content
    print(ai_response)
    if not isinstance(ai_response, str):
        print(f"Unexpected response type: {type(ai_response)}")
        return jsonify({'bot_response': 'An error occurred'})

    bot_response = ai_response

    # You can store the conversation history in a database or in-memory data structure

    return jsonify({'bot_response': bot_response})

if __name__ == '__main__':
    app.run(debug=True, port=5001)
